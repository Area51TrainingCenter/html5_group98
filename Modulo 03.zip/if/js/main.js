var num1=10;
var num2=56;

if(num1<num2)
{
	// ejecuta codigo si el resultado es verdad
	console.log("el num1 es mayor que num2")
}
else
{
	// ejecuta el codigo si el resultaod es falso
	console.log("el num2 es mayor")
}