console.log("Bienvenido a JS");

// Variable
// crear formulario con 3 campos
// nombre , correo , edad
var nombre;

var correo;
var edad;
var telefono;

nombre="Juan Carlos";
correo="jramos@gmail.com"
edad=22;

telefono=994994995;

telefono="994994995";
telefono="";


console.log(nombre,correo,edad);
console.log("nombre");
console.log(telefono);

// variables
/*
var texto;
var numero;
*/

/*  realiza las operaciones basicas de
	2 numeros  5 y 80  */
	var num1=3;
	var num2=8;
	var suma;
	var resta;
	var mul;
	var divi;
	// var num1,num2,num3,suma,resta,mul,div;


	num1=5;
	num2=0;

	suma=num1+num2;
	resta=num1-num2;
	mul=num1*num2;
	divi=num1/num2;

	console.log(suma);
	console.log(resta);
	console.log(mul);
	console.log(divi);

	console.log(num1+num2);
	console.log(num1-num2);
	console.log(num1*num2);
	console.log(num1/num2);

	console.log(5+80);
	console.log(5-80);
	console.log(5*80);
	console.log(5/80);
	var potencia;
	potencia=Math.pow(2,7);
	console.log(potencia);

	var maximo=Math.max(1,23,456,3,4576);
	var minimo=Math.min(1,23,456,3,4576);
	var raiz=Math.sqrt(144);
	var redondeo=Math.round(12.343);
	var aleatorio=Math.random();
	console.log("manejo de numero aleatorio");
	var numero=aleatorio*100;
	var final_numero=Math.round(numero);
	console.log(final_numero);




	


	







