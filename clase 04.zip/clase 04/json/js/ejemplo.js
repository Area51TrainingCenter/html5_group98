$(".lista-opciones li").click(function(){
	var opcion=$(this).attr("data-tipo");
	switch(opcion){
		case "fotos":
			// aquì va el codigo
			var url="https://jsonplaceholder.typicode.com/photos";
			traerDatos(url,"title")
			break;
		case "usuarios":
			var url="https://jsonplaceholder.typicode.com/users"
			traerDatos(url,"name")

			// aquì va el codigo
			break;
		case "post":
			// aquì va el codigo
			var url="https://jsonplaceholder.typicode.com/posts"
			traerDatos(url,"title")

			break;

	}
})

function traerDatos(url,propiedad){
	$(".contenido").html("");
	console.log("en la funcion traer datos")
	$.getJSON(url,function(result){
		for(var i=0;i<10;i++){
			$(".contenido").append("<p>"+result[i][propiedad]+"</p>")
		}
		
	})
}