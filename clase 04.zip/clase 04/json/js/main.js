console.log("ejemplo de consumo de json");
var url="https://jsonplaceholder.typicode.com/users";
$.getJSON("datos.json",function(resultado){
	console.log(resultado);
	for (var i = 0; i <resultado.length; i++) {
		var nombre=resultado[i].name;
		$(".listado").append("<li>"+nombre+"</li>")
	}
	
})